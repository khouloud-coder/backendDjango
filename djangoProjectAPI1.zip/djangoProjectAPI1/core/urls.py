from django.conf.urls import url, include
from rest_framework import routers

from core.views import (
    HealthRecordViewSet, PatientViewSet, DoctorViewSet, RelativeViewSet, BloodPressureViewSet, CommentViewSet,
    NotificationViewSet, DoctorRelationshipViewSet, RelativeRelationshipViewSet,TemperatureViewSet,CholesterolViewSet,RespiratoryParametersViewSet)

# Routers provide an easy way of automatically determining the URL conf.
router = routers.DefaultRouter()
router.register(r'health-records', HealthRecordViewSet, 'health-records')
router.register(r'patients', PatientViewSet, 'patients')
router.register(r'doctors', DoctorViewSet, 'doctors')
router.register(r'relatives', RelativeViewSet, 'relatives')
router.register(r'blood-pressures', BloodPressureViewSet, 'blood-pressures')
router.register(r'temperatures', TemperatureViewSet, 'temperatures')
router.register(r'cholesterols', CholesterolViewSet, 'cholesterol')
router.register(r'respiratory-parameters', RespiratoryParametersViewSet, 'respiratory-parameters')
router.register(r'comments', CommentViewSet, 'comments')
router.register(r'notifications', NotificationViewSet, 'notifications')
router.register(r'relative-relationships', RelativeRelationshipViewSet, 'relative-relationships')
router.register(r'doctor-relationships', DoctorRelationshipViewSet, 'doctor-relationships')

urlpatterns = [
    url(r'^', include(router.urls)),
]