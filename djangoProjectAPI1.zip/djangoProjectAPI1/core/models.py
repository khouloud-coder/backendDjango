from django.db import models

from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from django.utils.translation import gettext_lazy as _


class PersonalInformation(models.Model):
    pid = models.AutoField(primary_key=True)
    email = models.CharField(max_length=512)
    password = models.CharField(max_length=512)
    cell_phone = models.CharField(max_length=20)
    name = models.CharField(max_length=512)
    user_type = models.IntegerField()

    @property
    def relatives(self):
        if self.user_type != self.USER_TYPE_PATIENT:
            return []

        relatives = PersonalInformation.objects.filter(
            pid__in=RelativeRelationship.objects.filter(patient=self).values_list('relative__pid', flat=True)
        ).all()
        return relatives

    @property
    def doctors(self):
        if self.user_type != self.USER_TYPE_PATIENT:
            return []

        doctors = PersonalInformation.objects.filter(
            pid__in=DoctorRelationship.objects.filter(patient=self).values_list('doctor__pid', flat=True)
        ).all()
        return doctors

    USER_TYPE_DOCTOR = 1
    USER_TYPE_PATIENT = 2
    USER_TYPE_RELATIVE = 3

    READABLE_USER_TYPES = {
        USER_TYPE_DOCTOR: "Doctor",
        USER_TYPE_PATIENT: "Patient",
        USER_TYPE_RELATIVE: "Relative",
    }

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "<{user_type}: {pid}>  {name} - {email}".format(
            pid=self.pid,
            user_type=self.READABLE_USER_TYPES.get(self.user_type),
            name=self.name,
            email=self.email,
        )


class RelativeRelationship(models.Model):
    patient = models.ForeignKey(PersonalInformation, on_delete=models.CASCADE)
    relative = models.ForeignKey(PersonalInformation, related_name="relatives_relationships", on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Relative: {relative},  Patient: {patient}".format(
            relative=self.relative,
            patient=self.patient,
        )

    @classmethod
    def create_relative_relationships(cls, patient, relatives):
        for relative in relatives:
            cls.objects.create(patient=patient, relative=relative)

    @classmethod
    def update_relative_relationships(cls, patient, relatives):
        present_relatives = patient.relatives.all()

        for relative in relatives:
            if not (relative in present_relatives):
                cls.objects.create(patient=patient, relative=relative)

        cls.objects.filter(relative__in=set(present_relatives) - set(relatives)).delete()


class DoctorRelationship(models.Model):
    patient = models.ForeignKey(PersonalInformation, on_delete=models.CASCADE)
    doctor = models.ForeignKey(PersonalInformation, related_name="doctors_relationships", on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Doctor: {doctor},  Patient: {patient}".format(
            doctor=self.doctor,
            patient=self.patient,
        )

    @classmethod
    def create_doctor_relationships(cls, patient, doctors):
        for doctor in doctors:
            cls.objects.create(patient=patient, doctor=doctor)

    @classmethod
    def update_doctor_relationships(cls, patient, doctors):
        present_doctors = patient.doctors.all()

        for doctor in doctors:
            if not (doctor in present_doctors):
                cls.objects.create(patient=patient, doctor=doctor)

        cls.objects.filter(doctor__in=set(present_doctors) - set(doctors)).delete()


class HealthRecord(models.Model):
    class Bloods(models.TextChoices):
        APLUS = "A+", "A+"
        AMINUS = "A-", "A-"
        BPLUS = "B+", "B+"
        BMINUS = "B-", "B-"
        OPLUS = "O+", "O+"
        OMINUS = "O-", "O-"
        ABPLUS = "AB+", "AB+"
        ABMINUS = "AB-", "AB-"

    sex = models.BooleanField()
    birth = models.DateField()
    height = models.IntegerField()
    weight = models.IntegerField()
    bloodType = models.CharField(_("Blood"), max_length=50, choices=Bloods.choices)

    patient = models.ForeignKey(PersonalInformation, related_name='health_records', on_delete=models.CASCADE)

    SEX_MALE = True
    SEX_FEMALE = False

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "HealthRecord of {patient}".format(
            patient=self.patient,
        )



class Comment(models.Model):
    comment = models.TextField()
    time = models.DateTimeField()

    health_record = models.ForeignKey(HealthRecord, related_name='comments', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Comment by {patient}".format(
            patient=self.health_record.patient,
        )


class Notification(models.Model):
    TYPE = (
        ('temperature', 'temperature'),
        ('cholesterol', 'cholesterol'),
        ('blood pressure', 'blood pressure'),
        ('respiration', 'respiration')
    )

    type = models.CharField(max_length=20, null=True, choices=TYPE)
    parameter = models.FloatField()
    date_created = models.DateTimeField(auto_now_add=True, null=True)

    health_record = models.ForeignKey(HealthRecord, related_name='notifications', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Notification type {type} and its parameter {parameter} of {patient}".format(
            type=self.type,
            parameter=self.parameter,
            patient=self.health_record.patient,
        )


class Temperature(models.Model):
    temperature = models.FloatField()
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    health_record = models.ForeignKey(HealthRecord, related_name='temperatures', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Temperature {temperature} of {patient}".format(
            temperature=self.temperature,
            patient=self.health_record.patient,
        )


class Cholesterol(models.Model):
    ldl = models.FloatField()
    hdl = models.FloatField()
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    # patient = models.ForeignKey(Patient, null=True, on_delete=models.CASCADE)
    health_record = models.ForeignKey(HealthRecord, related_name='cholesterols', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "LDL {ldl} and  HDL {hdl} of {patient}".format(
            ldl=self.ldl,
            hdl=self.hdl,
            patient=self.health_record.patient,
        )


class BloodPressure(models.Model):
    systolicValue = models.FloatField()
    diastolicValue = models.FloatField()
    heartBeat = models.IntegerField()
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    # patient = models.ForeignKey(Patient, null=True, on_delete=models.CASCADE)
    health_record = models.ForeignKey(HealthRecord, related_name='blood_pressures', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Systolic value{systolicValue},Diastolic value{diastolicValue} and heart beat {heartBeat} of {patient}".format(
            systolicValue=self.systolicValue,
            diastolicValue=self.diastolicValue,
            heartBeat=self.heartBeat,
            patient=self.health_record.patient,
        )


class RespiratoryParameters(models.Model):
    respiratoryRate = models.IntegerField()
    pao2 = models.FloatField()
    pef = models.FloatField()
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    health_record = models.ForeignKey(HealthRecord, related_name='respiratory_parameters', on_delete=models.CASCADE)

    class Meta(object):
        app_label = "patients"

    def __str__(self):
        return "Respiratory Rate {respiratoryRate}, PaO2 {pao2} , PEF {pef} of {patient}".format(
            respiratoryRate=self.respiratoryRate,
            pao2=self.pao2,
            pef=self.pef,
            patient=self.health_record.patient,
        )



@receiver(post_save, sender=User)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
# Create your models here.
class Country(models.Model):
    name_fr= models.CharField(max_length=70)
    name_en= models.CharField(max_length=70)
    code_iso= models.CharField(max_length=70)
