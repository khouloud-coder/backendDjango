from django.contrib.auth.models import User
from rest_framework import serializers

from core.models import (
    PersonalInformation, HealthRecord, BloodPressure, Comment, Notification, RelativeRelationship, DoctorRelationship,Temperature,Cholesterol,RespiratoryParameters
)
from utils import GenderField


class PatientSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = PersonalInformation
        fields = (
            'pid', 'email', 'cell_phone', 'name', 'password', 'health_records', 'relatives', 'doctors','notifications'
        )
    password = serializers.CharField(style={'input_type': 'password'}, write_only=True)
    health_records = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        many=True,
        queryset=PersonalInformation.objects,
    )
    doctors = serializers.HyperlinkedRelatedField(
        view_name="doctors-detail",
        read_only=False,
        many=True,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_DOCTOR),
    )
    relatives = serializers.HyperlinkedRelatedField(
        view_name="relatives-detail",
        read_only=False,
        many=True,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_RELATIVE),
    )

    def create(self, validated_data):
        relatives = validated_data.pop("relatives", [])
        doctors = validated_data.pop("doctors", [])

        validated_data.update({
            "user_type": PersonalInformation.USER_TYPE_PATIENT
        })

        patient = super(PatientSerializer, self).create(validated_data)

        RelativeRelationship.create_relative_relationships(patient, relatives)
        DoctorRelationship.create_doctor_relationships(patient, doctors)

        User.objects.create_user(
            username=validated_data.get("email"),
            email=validated_data.get("email"),
            password=validated_data.get("password"),
        )

        return patient

    def update(self, instance, validated_data):
        relatives = validated_data.pop("relatives", [])
        doctors = validated_data.pop("doctors", [])

        patient = super(PatientSerializer, self).update(instance, validated_data)

        RelativeRelationship.update_relative_relationships(patient, relatives)
        DoctorRelationship.update_doctor_relationships(patient, doctors)

        user = User.objects.get(username=validated_data.get("email"))
        user.set_password(validated_data.get("password"))
        user.save()

        return patient


class DoctorSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = PersonalInformation
        fields = ('pid', 'email', 'cell_phone', 'name', 'password')
        extra_kwargs = {'password': {'write_only': True}}

    password = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    def create(self, validated_data):
        validated_data.update({
            "user_type": PersonalInformation.USER_TYPE_DOCTOR
        })

        User.objects.create_user(
            username=validated_data.get("email"),
            email=validated_data.get("email"),
            password=validated_data.get("password"),
        )

        return super(DoctorSerializer, self).create(validated_data)

    def update(self, instance, validated_data):
        user = User.objects.get(username=validated_data.get("email"))
        user.set_password(validated_data.get("password"))
        user.save()
        return super(DoctorSerializer, self).update(instance, validated_data)


class RelativeSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = PersonalInformation
        fields = ('pid', 'email', 'cell_phone', 'name', 'password')

    password = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    def create(self, validated_data):
        validated_data.update({
            "user_type": PersonalInformation.USER_TYPE_RELATIVE
        })

        User.objects.create_user(
            username=validated_data.get("email"),
            email=validated_data.get("email"),
            password=validated_data.get("password"),
        )

        return super(RelativeSerializer, self).create(validated_data)

    def update(self, instance, validated_data):
        user = User.objects.get(username=validated_data.get("email"))
        user.set_password(validated_data.get("password"))
        user.save()
        return super(RelativeSerializer, self).update(instance, validated_data)


class HealthRecordSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = HealthRecord
        fields = ('id', 'age', 'sex', 'height', 'weight', 'patient', 'blood_type', 'notifications','comments', 'temperatures','cholesterols','blood_pressures','respiratory_parameters')

    patient = serializers.HyperlinkedRelatedField(
        view_name="patients-detail",
        read_only=False,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_PATIENT),
    )

    temperatures = serializers.HyperlinkedRelatedField(
        view_name="temperatures-detail",
        read_only=True,
        many=True,
    )
    cholesterols = serializers.HyperlinkedRelatedField(
        view_name="cholesterols-detail",
        read_only=True,
        many=True,
    )
    blood_pressures = serializers.HyperlinkedRelatedField(
        view_name="blood_pressures-detail",
        read_only=True,
        many=True,
    )
    respiratory_parameters = serializers.HyperlinkedRelatedField(
        view_name="respiratory_parameters-detail",
        read_only=True,
        many=True,
    )
    comments = serializers.HyperlinkedRelatedField(
        view_name="comments-detail",
        read_only=True,
        many=True,
    )
    sex = GenderField()

    # added this
    # def create(self, validated_data):
    #     # validated_data.update({
    #     #     "user_type": PersonalInformation.USER_TYPE_RELATIVE
    #     # })
    #
    #     HealthRecord.objects.create_user(
    #         age=validated_data.get("age"),
    #         sex=validated_data.get("sex"),
    #         height=validated_data.get("height"),
    #         weight=validated_data.get("weight"),
    #         patient=validated_data.get("patient"),
    #         blood_type=validated_data.get("blood_type"),
    #         notifications=validated_data.get("notifications"),
    #         comments=validated_data.get("comments"),
    #         temperatures=validated_data.get("temperatures"),
    #         cholesterols=validated_data.get("cholesterols"),
    #         blood_pressures=validated_data.get("blood_pressures"),
    #         respiratory_parameters=validated_data.get("respiratory_parameters")
    #     )
    #
    #     return super(HealthRecordSerializer, self).create(validated_data)
    #
    # def update(self, instance, validated_data):
    #     healt_record = HealthRecord.objects.get(username=validated_data.get("email"))
    #     healt_record.set_age(validated_data.get("age"))
    #     healt_record.set_sex(validated_data.get("sex"))
    #     healt_record.set_height(validated_data.get("height"))
    #     healt_record.set_weight(validated_data.get("weight"))
    #     healt_record.set_blood_type(validated_data.get("blood_type"))
    #     healt_record.save()
    #     return super(HealthRecordSerializer, self).update(instance, validated_data)
    #
    #
    #


class NotificationSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = BloodPressure
        fields = ('id', 'type', 'parameter', 'date_created', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )


class CommentSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Comment
        fields = ('id', 'comment', 'time', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )


class TemperatureSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Temperature
        fields = ('id', 'temperature', 'date_created', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )
class CholesterolSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Temperature
        fields = ('id', 'ldl', 'hdl','date_created', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )
class BloodPressureSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Temperature
        fields = ('id', 'systolicValue', 'diastolicValue','heartBeat','date_created', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )
class RespiratoryParametersSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Temperature
        fields = ('id', 'respiratoryRate','pao2','pef', 'date_created', 'health_record')

    health_record = serializers.HyperlinkedRelatedField(
        view_name="health-records-detail",
        read_only=False,
        queryset=HealthRecord.objects,
    )


class RelativeRelationshipSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = RelativeRelationship
        fields = ('patient', 'relative')

    patient = serializers.HyperlinkedRelatedField(
        view_name="patients-detail",
        read_only=False,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_PATIENT),
    )
    relative = serializers.HyperlinkedRelatedField(
        view_name="relatives-detail",
        read_only=False,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_RELATIVE),
    )


class DoctorRelationshipSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = DoctorRelationship
        fields = ('patient', 'doctor')

    patient = serializers.HyperlinkedRelatedField(
        view_name="patients-detail",
        read_only=False,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_PATIENT),
    )
    doctor = serializers.HyperlinkedRelatedField(
        view_name="doctors-detail",
        read_only=False,
        queryset=PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_DOCTOR),
    )