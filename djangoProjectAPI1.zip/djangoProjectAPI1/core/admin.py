from django.contrib import admin

# Register your models here.
from core.models import *


admin.site.register(Notification)
admin.site.register(BloodPressure)
admin.site.register(Cholesterol)
admin.site.register(Temperature)
admin.site.register(RespiratoryParameters)
admin.site.register(PersonalInformation)
admin.site.register(RelativeRelationship)
admin.site.register(DoctorRelationship)
admin.site.register(HealthRecord)
admin.site.register(Comment)