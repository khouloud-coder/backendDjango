from rest_framework import viewsets
from rest_framework.authentication import TokenAuthentication
from rest_framework.authtoken import views
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import render


from core.models import (
    PersonalInformation, HealthRecord, BloodPressure, Comment, Notification, RelativeRelationship, DoctorRelationship,
    Temperature, Cholesterol, RespiratoryParameters
)
from core.serializers import (
    PatientSerializer, RelativeSerializer, DoctorSerializer, HealthRecordSerializer, BloodPressureSerializer,
    CommentSerializer, NotificationSerializer, RelativeRelationshipSerializer, DoctorRelationshipSerializer,
    TemperatureSerializer, CholesterolSerializer, RespiratoryParametersSerializer
)


class PatientViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    queryset = PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_PATIENT)
    serializer_class = PatientSerializer


    def destroy(self, request, pk=None, **kwargs):
        instance = PersonalInformation.objects.get(pid=pk)
        user_instance = User.objects.get(username=instance.email)
        user_instance.delete()
        instance.delete()
        return Response()


class DoctorViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_DOCTOR)
    serializer_class = DoctorSerializer

    def destroy(self, request, pk=None, **kwargs):
        instance = PersonalInformation.objects.get(pid=pk)
        user_instance = User.objects.get(username=instance.email)
        user_instance.delete()
        instance.delete()
        return Response()


class RelativeViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = PersonalInformation.objects.filter(user_type=PersonalInformation.USER_TYPE_RELATIVE)
    serializer_class = RelativeSerializer


def destroy(self, request, pk=None):
    instance = PersonalInformation.objects.get(pid=pk)
    user_instance = User.objects.get(username=instance.email)
    user_instance.delete()
    instance.delete()
    return Response()


class HealthRecordViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = HealthRecord.objects.all()
    serializer_class = HealthRecordSerializer

    # added this
    # def destroy(self, request, pk=None, **kwargs):
    #     instance = PersonalInformation.objects.get(pid=pk)
    #     user_instance = User.objects.get(username=instance.email)
    #     user_instance.delete()
    #     instance.delete()
    #     return Response()


class BloodPressureViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = BloodPressure.objects.all()
    serializer_class = BloodPressureSerializer


class TemperatureViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = Temperature.objects.all()
    serializer_class = TemperatureSerializer


class CholesterolViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = Cholesterol.objects.all()
    serializer_class = CholesterolSerializer


class RespiratoryParametersViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = RespiratoryParameters.objects.all()
    serializer_class = RespiratoryParametersSerializer


class CommentViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class NotificationViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer


class RelativeRelationshipViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = RelativeRelationship.objects.all()
    serializer_class = RelativeRelationshipSerializer


class DoctorRelationshipViewSet(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    queryset = DoctorRelationship.objects.all()
    serializer_class = DoctorRelationshipSerializer


class ObtainTokenView(views.ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        try:
            person = PersonalInformation.objects.get(email=user.email)
            personal_information = {
                "email": person.email,
                "type_readable": person.READABLE_USER_TYPES.get(person.user_type),
                "type": person.user_type,
                "pid": person.pid,
            }
        except PersonalInformation.DoesNotExist:
            personal_information = {}

        return Response({'token': token.key, 'personal_information': personal_information})


from django.shortcuts import render

# Create your views here.
